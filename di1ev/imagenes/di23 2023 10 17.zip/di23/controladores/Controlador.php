<?php
    class Controlador{
        function __construct(){//Controlador
            //constructor
        }
    }
?>
